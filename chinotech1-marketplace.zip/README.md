# CHINOTECH1 MARKETPLACE

GitHub Pages-ready marketplace starter.

Paystack: https://paystack.shop/pay/-b57cnxu3v

Upload `index.html` to a GitHub repository and enable GitHub Pages.